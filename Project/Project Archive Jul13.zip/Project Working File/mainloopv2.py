# AAC Prediction
# Workspace -- Project

from readFile import *
from collections import Counter
import collections
import sys


def main():

    print(

    
    """        *** Welcome to textpred for AAC devices! ***

---------------------------------------------------------------
***************************************************************
---------------------------------------------------------------

This software will predict the next five most probable letters

based on user input to aid in helping the handicap communicate

more effectivley and faster with others.

At any time, enter the value 0 to signal the end of your word.

---------------------------------------------------------------
***************************************************************
---------------------------------------------------------------

"""
)
    progmod()

def progmod():

    stop = 0
    stop2 = 0
    counter = 0
    finalword = str('')

    while (stop == 0):
        while (counter == 0):
            utext = input('Please Enter the first letter of your word: ').lower()
            print('')
            print('')
            letter = userinput(utext)
            finalword = finalword + str(letter)
            print("Your word is:", finalword)
            
            if (letter == 0):
                stop += 1
                counter += 1
        
            elif (letter !=0):
                wordlist = read_file(letter)
                cinput = chopper(wordlist, letter)
                lcount = counts(cinput)
                userscore = points(lcount, letter)
                counter += 1
                stop2 = 0
                
        while (counter >= 1) and (stop2 == 0):
            utext = input('Please enter another letter: ')
            checktext = userinput(utext)
            if (checktext == 0):
                stop = 1
                stop2 = 1
                print('Your final word was', finalword)
                print('Your final score was', userscore)
                
                break
            cinput = chopper(cinput, checktext)
            userscore += points(lcount, checktext)
            lcount = counts(cinput)
            finalword = finalword + str(checktext)
            print("Your word is:", finalword)


def userinput(atext):

    while (atext == '0'):
        print('Word Found!')
        print("Program Terminated")
        return 0
    
    while not atext.isalpha() and (atext != '0'):
            
        print('That is not a letter')
        atext = input('Please enter another letter: ').lower()
        
    return atext

def chopper(slist, utext):
    chopped = []

    
    while '' in slist:
        slist.remove('')
    for word in slist:
        if utext != word[0]:
            del word
        else:
            word = word[1:]
            chopped.append(word)
            
    return chopped

def counts(clist):
    llist = []
    
    for word in clist:
        x = word[0:1]
        llist.append(x)
        
    while '' in llist:
        llist.remove('')
    
    top_count = sorted(Counter((llist)).items(), key=lambda x: x[1], reverse = True)
    
    print("The next most probable letters are:", top_count[:5])
    return (top_count[:5])
    
def points(lcount, utext):
    
    user_print = [x[:1] for x in lcount]
    striplist = [j for i in user_print for j in i]

    total = 0

    
    
    if utext in striplist:
        
        if (utext == striplist[0]):
            print('Awarded 50 points!')
            total += 50
        elif (utext == striplist[1]) and (len(striplist) > 1):
            print('Awarded 40 points!')
            total += 40
        elif (utext == striplist[2]) and (len(striplist) > 2):
            print('Awarded 30 points!')
            total += 30
        elif (utext == striplist[3]) and (len(striplist) > 3):
            print('Awarded 20 points!')
            total += 20
        elif (len(striplist) > 4):
            if (utext == striplist[4]):
                print('Awarded 10 points!')
                total += 10
                
        return total
    else:
        print("You recieved no points for this letter.")
    
        return total    
main()
