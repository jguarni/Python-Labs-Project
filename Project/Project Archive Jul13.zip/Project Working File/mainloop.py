from readFile import *
from collections import Counter
import collections
import sys


def main():

    print(

    
    """        *** Welcome to textpred for AAC devices! ***

---------------------------------------------------------------
***************************************************************
---------------------------------------------------------------

This software will predict the next five most probable letters

based on user input to aid in helping the handicap communicate

more effectivley and faster with others.

At any time, enter the value 0 to signal the end of your word.

---------------------------------------------------------------
***************************************************************
---------------------------------------------------------------

"""
)
    progmod()

def progmod():

    stop = 0
    stop2 = 0
    counter = 0
    finalword = str('')

    while (stop == 0):
        while (counter == 0):
            utext = input('Please Enter the first letter of your word: ').lower()
            letter = userinput(utext)
            finalword = finalword + str(letter)
            print(finalword)
            
            if (letter == 0):
                stop += 1
                counter += 1
        
            elif (letter !=0):
                wordlist = read_file(letter)
                cinput = chopper(wordlist, letter)
                lcount = counts(cinput)
                counter += 1
                stop2 = 0
                
        while (counter >= 1) and (stop2 == 0):
            utext = input('Please enter another letter: ')
            checktext = userinput(utext)
            if (checktext == 0):
                stop = 1
                stop2 = 1
                print("Your final word is: ", finalword)
                break
            cinput = chopper(cinput, checktext)
            lcount = counts(cinput)
            finalword = finalword + str(checktext)
            print(finalword)
            
            

def userinput(atext):

    while (atext == '0'):
        print('Word Found!')
        print("Program Terminated")
        return 0
    
    while not atext.isalpha() and (atext != '0'):
            
        print('That is not a letter')
        atext = input('Please enter another letter: ').lower()
        
    return atext

def chopper(slist, utext):
    chopped = []
    for word in slist:
        if utext != word[0:1]:
            del word
        else:
            word = word[1:]
            chopped.append(word)
    return chopped

def counts(clist):
    llist = []
    for word in clist:
        x = word[0:1]
        llist.append(x)
    top_count = sorted(Counter((llist)).items(), key=lambda x: x[1], reverse = True)
    
    print(top_count[:5])
    

    
    
main()
