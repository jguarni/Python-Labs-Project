from readFile import *
from collections import Counter
import collections


def main():
    utext = input('Please Enter the first letter of your word: ').lower()
    letter = userinput(utext)
    wordlist = read_file(letter)
    cinput = chopper(wordlist, utext)
    lcount = counter(cinput)

    utext2 = input('Please enter another letter: ')
    cinput2 = chopper(cinput, utext2)
    lcount2 = counter(cinput2)

    utext3 = input('Please enter another letter: ')
    cinput3 = chopper(cinput2, utext3)
    lcount3 = counter(cinput3)
    
    utext4 = input('Please enter another letter: ')
    cinput4 = chopper(cinput3, utext4)
    lcount4 = counter(cinput4)
    
    utext5 = input('Please enter another letter: ')
    cinput5 = chopper(cinput4, utext5)
    lcount5 = counter(cinput5)

    utext6 = input('Please enter another letter: ')
    cinput6 = chopper(cinput5, utext6)
    lcount6 = counter(cinput6)

    utext7 = input('Please enter another letter: ')
    cinput7 = chopper(cinput6, utext7)
    lcount7 = counter(cinput7)
    
def userinput(atext):

    while not atext.isalpha():
        if (atext == 0):
            print("Program Terminated")
            utext = g
        print('That is not a letter')
        atext = input('Please enter another letter: ').lower()

    return atext

def chopper(slist, utext):
    chopped = []
    for word in slist:
        if utext != word[0:1]:
            del word
        else:
            word = word[1:]
            chopped.append(word)
    return chopped

def counter(clist):
    llist = []
    for word in clist:
        x = word[0:1]
        llist.append(x)
    top_count = sorted(Counter((llist)).items(), key=lambda x: x[1], reverse = True)
    
    print(top_count[:5])
    

    
    
main()
