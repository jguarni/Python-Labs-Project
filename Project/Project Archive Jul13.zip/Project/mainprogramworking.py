from readFile import *
from collections import Counter
import collections


def main():
    utext = input('Please Enter the first letter of your word: ').lower()
    letter = userinput(utext)
    wordlist = read_file(letter)
    fsearch = firstsearch(wordlist)
    
    
def userinput(atext):

    while not atext.isalpha():
        print('That is not a letter')
        atext = input('Please enter another letter: ').lower()

    return atext

def firstsearch(slist):
    for word in slist:
        word = word[1:]
        Count(word[0])

    
    
main()
