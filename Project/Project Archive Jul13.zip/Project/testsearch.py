from collections import Counter

find = "Balloon"

def lsearch(find):
    num = Counter(find)
    print(num)

lsearch(find)
