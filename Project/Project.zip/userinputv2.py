from readFile import *

def main():
    utext = input('Please Enter the first letter of your word: ').lower()
    letter = userinput(utext)
    read_file(letter)
    
def userinput(atext):

    while not atext.isalpha():
        print('That is not a letter')
        atext = input('Please enter another letter: ').lower()

    return atext

main()
